/**
 * Taro 4.2 app 配置
 * 页面路径和实际文件结构一一对应（二层结构：pages/xxx/index.tsx）
 */
export default {
  pages: [
    // TabBar 页面（5个）
    'pages/home/index',
    'pages/courses/index',
    'pages/hot-picks/index',
    'pages/news/index',
    'pages/vip/index',
    // 子页面（三层结构）
    'pages/courses/detail/index',
    'pages/hot-picks/detail/index',
    'pages/news/detail/index',
    'pages/vip/login/index',
    'pages/vip/register/index',
    'pages/vip/profile/index',
    'pages/vip/style-test/index',
    // 一级页面（二层结构）
    'pages/planning/index',
    'pages/buyer/index',
    'pages/collocation/index',
    'pages/contact/index',
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#1a56db',
    navigationBarTitleText: '骆芷蝶智选',
    navigationBarTextStyle: 'white',
  },
  tabBar: {
    color: '#999999',
    selectedColor: '#1a56db',
    borderStyle: 'white',
    backgroundColor: '#ffffff',
    list: [
      { pagePath: 'pages/home/index', text: '首页' },
      { pagePath: 'pages/courses/index', text: '课程企划' },
      { pagePath: 'pages/hot-picks/index', text: '爆款样衣' },
      { pagePath: 'pages/news/index', text: '资讯' },
      { pagePath: 'pages/vip/index', text: 'VIP' },
    ],
  },
}
