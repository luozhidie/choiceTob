import { View, Text, ScrollView, Image, Input, Button } from '@tarojs/components'
import { useState } from 'react'
import Taro from '@tarojs/taro'
import './index.scss'

/* ============ 联系方式数据 ============ */
const contactCards = [
  {
    icon: '📞',
    label: '咨询热线',
    value: '13925997776',
    desc: '周一至周六 9:00-18:00',
    bgColor: '#eff6ff',
    iconColor: '#1a56db',
    action: 'call',
  },
  {
    icon: '📧',
    label: '商务邮箱',
    value: 'luozhidie@live.cn',
    desc: '24小时内回复',
    bgColor: '#fffbeb',
    iconColor: '#f59e0b',
    action: 'copy',
  },
  {
    icon: '💬',
    label: '企业微信',
    value: '扫码添加企业微信',
    desc: '专属客服1对1服务',
    bgColor: '#f0fdf4',
    iconColor: '#16a34a',
    action: 'qrcode',
  },
  {
    icon: '📍',
    label: '公司地址',
    value: '深圳市南山区科技园',
    desc: '欢迎预约来访',
    bgColor: '#faf5ff',
    iconColor: '#9333ea',
    action: 'copy',
  },
]

/* ============ 社交媒体 ============ */
const socialLinks = [
  { label: '微信公众号', icon: '微', color: '#07c160' },
  { label: '微博', icon: '博', color: '#e6162d' },
  { label: '抖音', icon: '抖', color: '#1a1a1a' },
  { label: '小红书', icon: '红', color: '#ff2442' },
]

/* ============ 咨询类型 ============ */
const consultTypes = [
  '平台入驻咨询',
  '商品合作',
  '品牌授权',
  '技术对接',
  '培训服务',
  '其他',
]

export default function ContactPage() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    type: '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)
  const [showQRCode, setShowQRCode] = useState(false)

  const handleContactAction = (card: typeof contactCards[0]) => {
    switch (card.action) {
      case 'call':
        Taro.makePhoneCall({ phoneNumber: card.value })
        break
      case 'copy':
        Taro.setClipboardData({ data: card.value })
        break
      case 'qrcode':
        setShowQRCode(true)
        break
    }
  }

  const handleSubmit = () => {
    if (!form.name.trim()) {
      Taro.showToast({ title: '请输入姓名', icon: 'none' })
      return
    }
    if (!form.phone.trim()) {
      Taro.showToast({ title: '请输入电话', icon: 'none' })
      return
    }
    if (!form.type) {
      Taro.showToast({ title: '请选择咨询类型', icon: 'none' })
      return
    }
    if (!form.message.trim()) {
      Taro.showToast({ title: '请输入留言内容', icon: 'none' })
      return
    }

    // 模拟提交成功
    setSubmitted(true)
    setForm({ name: '', phone: '', type: '', message: '' })
    Taro.showToast({ title: '留言提交成功！', icon: 'success' })
    setTimeout(() => setSubmitted(false), 4000)
  }

  const handleTypeSelect = (type: string) => {
    setForm({ ...form, type })
  }

  return (
    <View className="contact-page">
      <ScrollView scrollY className="contact-scroll">
        {/* ====== Hero ====== */}
        <View className="contact-hero">
          <View className="contact-hero-overlay" />
          <View className="contact-hero-content">
            <View className="contact-hero-badge">
              <Text className="contact-hero-badge-text">📞 联系我们</Text>
            </View>
            <Text className="contact-hero-title">与我们取得联系</Text>
            <Text className="contact-hero-desc">无论是平台入驻、商品合作还是品牌授权，我们的专业团队随时为您提供支持</Text>
          </View>
        </View>

        {/* ====== 联系方式卡片 ====== */}
        <View className="contact-section">
          <View className="contact-cards">
            {contactCards.map((card, idx) => (
              <View
                key={idx}
                className="contact-card"
                onClick={() => handleContactAction(card)}
              >
                <View className="contact-card-icon-wrap" style={{ backgroundColor: card.bgColor }}>
                  <Text className="contact-card-icon">{card.icon}</Text>
                </View>
                <Text className="contact-card-label">{card.label}</Text>
                <Text className="contact-card-value">{card.value}</Text>
                <Text className="contact-card-desc">{card.desc}</Text>

                {/* 微信二维码展示 */}
                {card.action === 'qrcode' && showQRCode && (
                  <View className="contact-qr-section">
                    <View className="contact-qr-placeholder">
                      <Text className="contact-qr-placeholder-text">企业微信二维码{'\n'}（长按识别添加）</Text>
                    </View>
                    <Text className="contact-qr-hint">微信扫一扫添加客服</Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* ====== 在线留言 ====== */}
        <View className="contact-section">
          <View className="section-header-center">
            <Text className="section-label">ONLINE MESSAGE</Text>
            <Text className="section-title-center">给我们留言</Text>
            <Text className="section-desc-center">填写以下信息，我们的专属顾问将尽快与您联系</Text>
          </View>

          <View className="form-card">
            {/* 姓名 */}
            <View className="form-item">
              <Text className="form-label">姓名 <Text className="form-required">*</Text></Text>
              <Input
                className="form-input"
                placeholder="请输入您的姓名"
                value={form.name}
                onInput={(e) => setForm({ ...form, name: e.detail.value })}
              />
            </View>

            {/* 电话 */}
            <View className="form-item">
              <Text className="form-label">电话 <Text className="form-required">*</Text></Text>
              <Input
                className="form-input"
                type="number"
                placeholder="请输入联系电话"
                value={form.phone}
                onInput={(e) => setForm({ ...form, phone: e.detail.value })}
              />
            </View>

            {/* 咨询类型 */}
            <View className="form-item">
              <Text className="form-label">咨询类型 <Text className="form-required">*</Text></Text>
              <View className="form-type-grid">
                {consultTypes.map(type => (
                  <View
                    key={type}
                    className={`form-type-item ${form.type === type ? 'active' : ''}`}
                    onClick={() => handleTypeSelect(type)}
                  >
                    <Text className={`form-type-text ${form.type === type ? 'active' : ''}`}>{type}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* 留言 */}
            <View className="form-item">
              <Text className="form-label">留言内容 <Text className="form-required">*</Text></Text>
              <Input
                className="form-input form-textarea"
                placeholder="请描述您的需求或问题..."
                value={form.message}
                onInput={(e) => setForm({ ...form, message: e.detail.value })}
              />
            </View>

            {/* 提交按钮 */}
            <View className="form-submit-btn" onClick={handleSubmit}>
              <Text className="form-submit-text">提交留言</Text>
            </View>
          </View>

          {/* 提交成功提示 */}
          {submitted && (
            <View className="submit-toast">
              <Text className="submit-toast-icon">✅</Text>
              <Text className="submit-toast-title">留言提交成功！</Text>
              <Text className="submit-toast-desc">我们将在24小时内与您取得联系</Text>
            </View>
          )}
        </View>

        {/* ====== 关注我们 ====== */}
        <View className="contact-section">
          <View className="social-card">
            <Text className="social-title">🌐 关注我们</Text>
            <View className="social-grid">
              {socialLinks.map((s, idx) => (
                <View key={idx} className="social-item">
                  <View className="social-icon" style={{ backgroundColor: s.color }}>
                    <Text className="social-icon-text">{s.icon}</Text>
                  </View>
                  <Text className="social-label">{s.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* ====== CTA ====== */}
        <View className="cta-section">
          <Text className="cta-title">期待与您携手共赢</Text>
          <Text className="cta-desc">骆芷蝶智选致力于构建高效协同的服装供应链生态，期待您的加入</Text>
          <View className="cta-btn" onClick={() => Taro.makePhoneCall({ phoneNumber: '13925997776' })}>
            <Text className="cta-btn-text">📞 拨打热线 13925997776</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}
