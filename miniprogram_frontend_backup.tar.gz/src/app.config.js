/**
 * Taro 4.2 app 配置（CommonJS，无 TS 无 Taro require）
 * 必须确保此文件不被 webpack 处理（否则会触发 ENABLE_INNER_HTML 错误）
 */
module.exports = {
  pages: [
    'pages/home/index/index',
    'pages/courses/index/index',
    'pages/hot-picks/index/index',
    'pages/news/index/index',
    'pages/vip/index/index',
    'pages/courses/detail/index/index',
    'pages/planning/index/index',
    'pages/hot-picks/detail/index/index',
    'pages/news/detail/index/index',
    'pages/vip/login/index/index',
    'pages/vip/register/index/index',
    'pages/vip/profile/index/index',
    'pages/vip/style-test/index/index',
    'pages/buyer/index/index',
    'pages/collocation/index/index',
    'pages/contact/index/index',
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#1a56db',
    navigationBarTitleText: '骆芷蝶智选',
    navigationBarTextStyle: 'white',
  },
  tabBar: {
    color: '#999999',
    selectedColor: '#1a56db',
    borderStyle: 'white',
    backgroundColor: '#ffffff',
    list: [
      { pagePath: 'pages/home/index/index', text: '首页' },
      { pagePath: 'pages/courses/index/index', text: '课程企划' },
      { pagePath: 'pages/hot-picks/index/index', text: '爆款样衣' },
      { pagePath: 'pages/news/index/index', text: '资讯' },
      { pagePath: 'pages/vip/index/index', text: 'VIP' },
    ],
  },
}
