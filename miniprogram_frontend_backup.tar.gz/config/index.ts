import { defineConfig } from '@tarojs/cli'
import devConfig from './dev'
import prodConfig from './prod'

export default defineConfig(async (merge) => {
  const baseConfig = {
    projectName: 'luozhidie-choice',
    date: '2026-5-21',
    designWidth: 750,
    deviceRatio: { 640: 2.34 / 2, 750: 1, 375: 2, 828: 1.81 / 2 },
    sourceRoot: 'src',
    outputRoot: 'dist',
    plugins: [],
    defineConstants: {},
    copy: { patterns: [], options: {} },
    framework: 'react',
    // compiler: 'webpack5', // 注释掉，用 Taro 默认 compiler
    cache: { enable: false },
    mini: {
      postcss: {
        pxtransform: { enable: true, config: {} },
        cssModules: { enable: false, config: { namingPattern: 'module', generateScopedName: '[name]__[local]___[hash:base64:5]' } }
      },
      optimizeMainPackage: { enable: false },
      webpackChain(chain) {
        // 禁用 progress 插件，避免 webpack 5.91 兼容问题
        try { chain.plugin('progress').tap(() => [false]); } catch(e) {}
        try { chain.plugin('ProgressPlugin').tap(() => [false]); } catch(e) {}
        // 排除 app.config.js 不被 taro-loader 处理（解决 ENABLE_INNER_HTML 错误）
        chain.module.rule('excludeAppConfig').test(/src[\\/]app\.config\.(js|ts)$/).exclude.add(/.*/).end()
      }
    },
    h5: {
      publicPath: '/',
      staticDirectory: 'static',
      postcss: {
        autoprefixer: { enable: true, config: {} },
        cssModules: { enable: false, config: { namingPattern: 'module', generateScopedName: '[name]__[local]___[hash:base64:5]' } }
      }
    }
  };
  if (process.env.NODE_ENV === 'development') return merge({}, baseConfig, devConfig);
  return merge({}, baseConfig, prodConfig);
})
